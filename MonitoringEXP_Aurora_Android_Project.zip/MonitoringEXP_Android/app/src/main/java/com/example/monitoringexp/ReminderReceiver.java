package com.example.monitoringexp;

import android.app.*;
import android.content.*;
import android.os.*;
import androidx.core.app.NotificationCompat;
import java.util.*;

public class ReminderReceiver extends BroadcastReceiver {
    static final String CH="exp_reminders";
    static PendingIntent pi(Context c,String id){return PendingIntent.getBroadcast(c,("rem_"+id).hashCode(),new Intent(c,ReminderReceiver.class).setAction("REMINDER").putExtra("id",id),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
    public static void schedule(Context c,String id,long when,String msg,boolean speak){
        SharedPreferences p=c.getSharedPreferences("reminders",0);p.edit().putLong(id+".when",when).putString(id+".msg",msg).putBoolean(id+".speak",speak).apply();
        AlarmManager am=(AlarmManager)c.getSystemService(ALARM_SERVICE); PendingIntent pi=pi(c,id);
        if(Build.VERSION.SDK_INT>=31 && am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi); else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
    }
    public static void cancel(Context c,String id){AlarmManager am=(AlarmManager)c.getSystemService(ALARM_SERVICE);am.cancel(pi(c,id));c.getSharedPreferences("reminders",0).edit().remove(id+".when").remove(id+".msg").remove(id+".speak").apply();}
    @Override public void onReceive(Context c,Intent i){ if(!"REMINDER".equals(i.getAction()))return;String id=i.getStringExtra("id");SharedPreferences p=c.getSharedPreferences("reminders",0);String msg=p.getString(id+".msg","Pengingat Monitoring EXP");boolean speak=p.getBoolean(id+".speak",true);show(c,msg);if(speak)new Thread(()->{try{final android.speech.tts.TextToSpeech[] box=new android.speech.tts.TextToSpeech[1];box[0]=new android.speech.tts.TextToSpeech(c,x->{if(x==0){if(android.os.Build.VERSION.SDK_INT>=21)box[0].speak(msg,android.speech.tts.TextToSpeech.QUEUE_FLUSH,null,"exp");else box[0].speak(msg,android.speech.tts.TextToSpeech.QUEUE_FLUSH,null);}} ,"id-ID");}catch(Exception ignored){}}).start();p.edit().remove(id+".when").remove(id+".msg").remove(id+".speak").apply();}
    static void show(Context c,String msg){NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);if(Build.VERSION.SDK_INT>=26){NotificationChannel ch=new NotificationChannel(CH,"Pengingat EXP",NotificationManager.IMPORTANCE_HIGH);ch.setDescription("Alarm dan pengingat tanggal expired");ch.enableVibration(true);ch.setSound(android.provider.Settings.System.DEFAULT_NOTIFICATION_URI,null);nm.createNotificationChannel(ch);}Intent launch=c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());PendingIntent content=PendingIntent.getActivity(c,1,launch,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Notification n=new NotificationCompat.Builder(c,CH).setSmallIcon(android.R.drawable.ic_dialog_alert).setContentTitle("⏰ Monitoring EXP").setContentText(msg).setStyle(new NotificationCompat.BigTextStyle().bigText(msg)).setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(content).setDefaults(Notification.DEFAULT_ALL).build();nm.notify((int)System.currentTimeMillis(),n);}
}
