package com.example.monitoringexp;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.webkit.*;
import android.widget.Toast;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import android.util.Base64;

public class MainActivity extends Activity {
    WebView web;
    static final int REQ_NOTIF=42;
    @Override public void onCreate(Bundle b){ super.onCreate(b); setup(); handleIntent(getIntent()); }
    void setup(){
        web=new WebView(this); setContentView(web);
        WebView.setWebContentsDebuggingEnabled(false);
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setMediaPlaybackRequiresUserGesture(false);
        web.setWebViewClient(new WebViewClient()); web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p){
                Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("text/csv"); startActivityForResult(i,1001); pending=cb; return true;
            }
        });
        web.addJavascriptInterface(new AndroidBridge(),"AndroidBridge");
        web.loadUrl("file:///android_asset/index.html");
        if(Build.VERSION.SDK_INT>=33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ_NOTIF);
    }
    ValueCallback<Uri[]> pending;
    @Override protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);handleIntent(i);}
    void handleIntent(Intent intent){
        if(intent==null) return; String action=intent.getAction(); Uri u=intent.getData();
        if(Intent.ACTION_VIEW.equals(action)&&u!=null) importUri(u);
        else if(Intent.ACTION_SEND.equals(action)){ Uri x=intent.getParcelableExtra(Intent.EXTRA_STREAM); if(x!=null) importUri(x); else {String t=intent.getStringExtra(Intent.EXTRA_TEXT); if(t!=null) importText(t,"Shared text");}}
    }
    void importUri(Uri uri){ new Thread(()->{try(InputStream in=getContentResolver().openInputStream(uri)){byte[] data=readAll(in);String text=new String(data,StandardCharsets.UTF_8); runOnUiThread(()->importText(text,uri.getLastPathSegment()==null?"file":uri.getLastPathSegment()));}catch(Exception e){runOnUiThread(()->toast("Gagal membuka file: "+e.getMessage()));}}).start(); }
    void importText(String text,String name){ String safe=Base64.encodeToString(text.getBytes(StandardCharsets.UTF_8),Base64.NO_WRAP); web.evaluateJavascript("window.importTextFromNative && window.importTextFromNative("+JSONObjectQuote(safe)+","+JSONObjectQuote(name)+")",null); toast("File diterima: "+name); }
    static String JSONObjectQuote(String s){return "\""+s.replace("\\","\\\\").replace("\"","\\\"")+"\"";}
    static byte[] readAll(InputStream in)throws IOException{ByteArrayOutputStream o=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=in.read(b))>0)o.write(b,0,n);return o.toByteArray();}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    public class AndroidBridge{
        @JavascriptInterface public void saveFile(String filename,String mime,String text){
            Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType(mime); i.putExtra(Intent.EXTRA_TITLE,filename); pendingSaveText=text; startActivityForResult(i,1002);
        }
        @JavascriptInterface public void emailFile(String filename,String mime,String text){
            try{File f=writeCache(filename,text);Uri uri=FileProvider.getUriForFile(MainActivity.this,"com.example.monitoringexp.fileprovider",f);Intent i=new Intent(Intent.ACTION_SEND);i.setType(mime);i.putExtra(Intent.EXTRA_SUBJECT,"Monitoring EXP - "+filename);i.putExtra(Intent.EXTRA_TEXT,"File Monitoring EXP terlampir.");i.putExtra(Intent.EXTRA_STREAM,uri);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,"Kirim file via email"));}catch(Exception e){toast("Gagal menyiapkan email");}
        }
        @JavascriptInterface public void scheduleReminder(String id,long when,String message,boolean speak){ ReminderReceiver.schedule(MainActivity.this,id,when,message,speak); }
        @JavascriptInterface public void cancelReminder(String id){ ReminderReceiver.cancel(MainActivity.this,id); }
        @JavascriptInterface public void openExactAlarmSettings(){ if(Build.VERSION.SDK_INT>=31) try{startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:"+getPackageName())));}catch(Exception ignored){} }
    }
    String pendingSaveText;
    @Override protected void onActivityResult(int r,int c,Intent d){
        super.onActivityResult(r,c,d);
        if(r==1001&&pending!=null){pending.onReceiveValue(c==RESULT_OK&&d!=null?new Uri[]{d.getData()}:null);pending=null;}
        if(r==1002&&c==RESULT_OK&&d!=null&&pendingSaveText!=null){try(OutputStream o=getContentResolver().openOutputStream(d.getData())){o.write(pendingSaveText.getBytes(StandardCharsets.UTF_8));toast("File berhasil diekspor");}catch(Exception e){toast("Gagal menyimpan file");}pendingSaveText=null;}
    }
    File writeCache(String filename,String text)throws IOException{File dir=new File(getCacheDir(),"shared");dir.mkdirs();File f=new File(dir,filename.replaceAll("[^a-zA-Z0-9._-]","_"));try(FileOutputStream o=new FileOutputStream(f)){o.write(text.getBytes(StandardCharsets.UTF_8));}return f;}
}
