package com.example.monitoringexp;
import android.content.*;
import java.util.*;
public class BootReceiver extends BroadcastReceiver{
 @Override public void onReceive(Context c,Intent i){if(!Intent.ACTION_BOOT_COMPLETED.equals(i.getAction())&&!Intent.ACTION_MY_PACKAGE_REPLACED.equals(i.getAction()))return;android.content.SharedPreferences p=c.getSharedPreferences("reminders",0);for(String k:p.getAll().keySet())if(k.endsWith(".when")){String id=k.substring(0,k.length()-5);long when=p.getLong(k,0);if(when>System.currentTimeMillis())ReminderReceiver.schedule(c,id,when,p.getString(id+".msg","Pengingat"),p.getBoolean(id+".speak",true));}}
}
