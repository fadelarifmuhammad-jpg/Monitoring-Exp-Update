# Monitoring EXP Aurora — Android

Project Android Studio untuk membungkus prototype `Monitoring EXP` menjadi aplikasi Android native + WebView.

## Fitur utama
- Tema Aurora gelap dengan efek cahaya.
- Dashboard Total Produk, Expired, ≤7 hari, ≤30 hari.
- Cari/filter, tambah/edit/hapus produk.
- Scan barcode: prototype tetap mendukung kamera/foto; wrapper Android sudah meminta permission CAMERA sehingga dapat dikembangkan ke ML Kit native.
- Export CSV/JSON memakai Android Storage Access Framework.
- Kirim CSV sebagai lampiran melalui aplikasi email yang tersedia (Gmail/Outlook/dll).
- Buka/import CSV atau JSON yang diterima dari email/file manager melalui menu "Open with" atau "Share" ke Monitoring EXP.
- Pengingat tanggal/jam dengan notifikasi alarm, getar, dan pembacaan suara TTS Bahasa Indonesia bila tersedia.
- Pengingat dapat dibuat manual atau langsung dari baris produk (ikon ⏰), default satu hari sebelum EXP.
- Pengingat dijadwalkan ulang setelah reboot/update aplikasi.

## Cara membuka
1. Buka folder ini di Android Studio.
2. Gunakan Android SDK 35 dan Gradle yang kompatibel dengan Android Gradle Plugin 8.11.0.
3. Sync Gradle lalu Run pada HP Android.

## Catatan izin
- Notifikasi diperlukan agar alarm/pengingat muncul.
- Alarm presisi memakai izin `SCHEDULE_EXACT_ALARM` bila tersedia; jika tidak, aplikasi memakai jadwal Android yang lebih hemat baterai.
- Kamera disiapkan untuk fitur barcode.

## Integrasi email
Tombol **✉️ Kirim Email** membuat file CSV dan membuka chooser Android dengan file sebagai attachment. Untuk menerima file, dari Gmail/Outlook pilih **Buka dengan / Bagikan** lalu pilih Monitoring EXP. CSV/JSON akan dimasukkan ke database aplikasi.

## Data
Database utama tetap memakai localStorage dari prototype, sehingga data awal dan struktur kolom dari file asli dipertahankan.
