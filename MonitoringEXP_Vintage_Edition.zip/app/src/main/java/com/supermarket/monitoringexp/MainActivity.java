package com.supermarket.monitoringexp;

import android.Manifest;import android.app.*;import android.content.*;import android.content.pm.PackageManager;import android.graphics.*;import android.graphics.drawable.*;import android.net.Uri;import android.os.*;import android.provider.OpenableColumns;import android.view.*;import android.widget.*;import androidx.appcompat.app.AppCompatActivity;import androidx.core.content.FileProvider;import java.io.*;import java.nio.charset.StandardCharsets;import java.text.*;import java.util.*;import org.json.*;

public class MainActivity extends AppCompatActivity {
    Db db; LinearLayout content; TextView title,sub; int aqua=Color.rgb(184,132,58); int green=Color.rgb(61,112,62);
    int navy=Color.rgb(62,39,24), text=Color.rgb(61,43,29), muted=Color.rgb(112,91,70), surface=Color.rgb(239,225,194);
    int parchment=Color.rgb(248,238,211), wood=Color.rgb(78,48,29), gold=Color.rgb(185,133,54), red=Color.rgb(174,55,43);
    boolean homePage=true;
    @Override public void onCreate(Bundle b){super.onCreate(b);db=new Db(this);AlarmScheduler.ensureChannel(this);requestNotifications();showHome();handleIncoming(getIntent());}
    @Override protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);handleIncoming(i);}
    void requestNotifications(){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},7);}
    GradientDrawable gradient(int... c){return new GradientDrawable(GradientDrawable.Orientation.TL_BR,c);}
    TextView tv(String s,float sp,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(color);t.setFontFeatureSettings("kern");t.setTypeface(android.graphics.Typeface.create("serif",android.graphics.Typeface.NORMAL));return t;}
    TextView label(String s){TextView t=tv(s,13,muted);t.setPadding(0,4,0,4);return t;}
    LinearLayout root(){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setBackgroundColor(surface);return r;}
    Button button(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(16);b.setTextColor(Color.WHITE);b.setTypeface(android.graphics.Typeface.create("serif",1));b.setMinHeight(dp(58));b.setPadding(dp(12),dp(8),dp(12),dp(8));b.setBackground(rounded(wood,12));return b;}
    TextView navItem(String icon,String name){TextView t=tv(icon+"\n"+name,11,muted);t.setGravity(Gravity.CENTER);t.setPadding(4,7,4,5);return t;}
    TextView stat(String icon,String name){TextView t=tv(icon+"  "+name+"\n0",12,Color.WHITE);t.setGravity(Gravity.CENTER_VERTICAL);t.setPadding(14,12,8,12);t.setTypeface(null,1);return t;}
    void base(String page,String caption){homePage=false;LinearLayout r=root();r.setBackgroundColor(surface);LinearLayout head=new LinearLayout(this);head.setPadding(dp(10),dp(8),dp(10),dp(8));head.setGravity(Gravity.CENTER_VERTICAL);TextView back=tv("‹",42,Color.WHITE);back.setGravity(Gravity.CENTER);back.setBackground(rounded(wood,28));head.addView(back,new LinearLayout.LayoutParams(dp(52),dp(52)));LinearLayout hh=new LinearLayout(this);hh.setOrientation(LinearLayout.VERTICAL);hh.setPadding(dp(12),0,0,0);title=tv(page,24,Color.WHITE);title.setTypeface(android.graphics.Typeface.create("serif",1));sub=tv(caption,12,Color.rgb(239,220,174));hh.addView(title);hh.addView(sub);head.addView(hh,new LinearLayout.LayoutParams(0,-2,1));head.setBackground(gradient(Color.rgb(54,34,22),wood,Color.rgb(108,72,39)));r.addView(head);back.setOnClickListener(v->showHome());content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(14),dp(12),dp(14),dp(18));ScrollView sv=new ScrollView(this);sv.setFillViewport(true);sv.addView(content);r.addView(sv,new LinearLayout.LayoutParams(-1,0,1));setContentView(r);}
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    GradientDrawable rounded(int color,float radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));return g;}
    GradientDrawable roundedStroke(int color,float radius,int strokeColor){GradientDrawable g=rounded(color,radius);g.setStroke(dp(1),strokeColor);return g;}
    TextView bigIcon(String s,float size){TextView t=tv(s,size,Color.WHITE);t.setGravity(Gravity.CENTER);return t;}
    LinearLayout homeCard(String icon,String name,String desc,int color){LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.HORIZONTAL);card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(14),dp(12),dp(8),dp(12));card.setBackground(roundedStroke(parchment,14,Color.rgb(191,157,103)));card.setMinimumHeight(dp(124));LinearLayout left=new LinearLayout(this);left.setOrientation(LinearLayout.VERTICAL);left.setGravity(Gravity.CENTER_VERTICAL);TextView ic=tv(icon,29,text);ic.setGravity(Gravity.CENTER_VERTICAL);TextView nm=tv(name,19,text);nm.setTypeface(android.graphics.Typeface.create("serif",1));nm.setPadding(0,dp(3),0,dp(2));TextView ds=tv(desc,12,muted);left.addView(ic,new LinearLayout.LayoutParams(-1,dp(34)));left.addView(nm);left.addView(ds);card.addView(left,new LinearLayout.LayoutParams(0,-2,1));TextView arrow=tv("›",34,wood);arrow.setGravity(Gravity.CENTER);card.addView(arrow,new LinearLayout.LayoutParams(dp(30),dp(60)));return card;}
    void showHome(){
        homePage=true;LinearLayout r=root();r.setBackgroundColor(surface);

        // Header / hero: larger typography and generous touch targets.
        LinearLayout hero=new LinearLayout(this);hero.setOrientation(LinearLayout.VERTICAL);hero.setPadding(dp(20),dp(18),dp(16),dp(18));hero.setBackground(gradient(Color.rgb(55,35,22),wood,Color.rgb(120,82,40)));
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo=new ImageView(this);logo.setImageResource(com.supermarket.monitoringexp.R.drawable.ic_monitoring_exp);top.addView(logo,new LinearLayout.LayoutParams(dp(62),dp(62)));
        LinearLayout ht=new LinearLayout(this);ht.setOrientation(LinearLayout.VERTICAL);ht.setPadding(dp(12),0,0,0);
        TextView a=tv("MONITORING EXP",26,Color.rgb(255,239,199));a.setTypeface(null,1);
        TextView b=tv("Pantau • Kelola • Ingat • Selalu",14,Color.rgb(238,216,173));b.setPadding(0,dp(2),0,0);ht.addView(a);ht.addView(b);
        top.addView(ht,new LinearLayout.LayoutParams(0,-2,1));
        TextView set=tv("⚙",30,Color.WHITE);set.setGravity(Gravity.CENTER);top.addView(set,new LinearLayout.LayoutParams(dp(50),dp(62)));
        hero.addView(top);
        TextView welcome=tv("Tetap satu langkah di depan masa expired.",18,Color.rgb(255,239,199));welcome.setTypeface(null,1);welcome.setPadding(dp(4),dp(18),dp(4),dp(4));hero.addView(welcome);
        r.addView(hero,new LinearLayout.LayoutParams(-1,dp(178)));
        set.setOnClickListener(v->showSettings());

        // Dashboard counters: still four columns, but with bigger cards and type.
        LinearLayout stats=new LinearLayout(this);stats.setPadding(dp(10),dp(10),dp(10),dp(8));stats.setGravity(Gravity.CENTER_VERTICAL);
        TextView s1=stat("📦","Total Produk"),s2=stat("🚨","Expired"),s3=stat("⏳","≤ 7 Hari"),s4=stat("📅","≤ 30 Hari");
        TextView[] ss={s1,s2,s3,s4};int[] sc={Color.rgb(54,112,65),Color.rgb(174,55,43),Color.rgb(190,126,25),Color.rgb(91,65,115)};
        for(int i=0;i<ss.length;i++){TextView x=ss[i];x.setTextSize(13);x.setTypeface(null,1);x.setGravity(Gravity.CENTER);x.setPadding(dp(4),dp(10),dp(4),dp(10));x.setBackground(rounded(sc[i],14));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(102),1);lp.setMargins(dp(3),0,dp(3),0);stats.addView(x,lp);}
        r.addView(stats);updateStats(s1,s2,s3,s4);

        // Main content is scrollable so the larger controls remain comfortable on small screens.
        ScrollView sv=new ScrollView(this);sv.setFillViewport(true);LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(dp(12),dp(8),dp(12),dp(14));
        LinearLayout heading=new LinearLayout(this);heading.setGravity(Gravity.CENTER_VERTICAL);TextView grid=tv("▦",32,Color.rgb(255,239,199));grid.setGravity(Gravity.CENTER);grid.setBackground(rounded(wood,14));heading.addView(grid,new LinearLayout.LayoutParams(dp(56),dp(56)));TextView ih=tv("Pusat perhatian",25,text);ih.setTypeface(null,1);ih.setPadding(dp(14),0,0,0);heading.addView(ih,new LinearLayout.LayoutParams(0,-2,1));body.addView(heading);
        TextView desc=tv("Kelola produk, alarm, laporan, dan pekerjaan dari satu aplikasi.",15,muted);desc.setPadding(dp(70),dp(2),0,dp(14));body.addView(desc);

        // Large 2-column action grid.
        LinearLayout row1=new LinearLayout(this);row1.setGravity(Gravity.CENTER);LinearLayout products=homeCard("📦","Produk","Kelola data produk",Color.rgb(61,112,62));LinearLayout alarms=homeCard("🔔","Alarm","Lihat & kelola alarm expired",Color.rgb(174,55,43));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,dp(124),1);cp.setMargins(dp(4),dp(4),dp(4),dp(4));row1.addView(products,cp);LinearLayout.LayoutParams cp2=new LinearLayout.LayoutParams(0,dp(124),1);cp2.setMargins(dp(4),dp(4),dp(4),dp(4));row1.addView(alarms,cp2);body.addView(row1);
        LinearLayout row2=new LinearLayout(this);LinearLayout reports=homeCard("📋","Laporan","Lihat laporan & rekapitulasi",Color.rgb(153,104,45));LinearLayout scanner=homeCard("▣","Scan Barcode","Scan produk dengan kamera",Color.rgb(91,65,115));
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(0,dp(124),1);rp.setMargins(dp(4),dp(4),dp(4),dp(4));row2.addView(reports,rp);LinearLayout.LayoutParams rp2=new LinearLayout.LayoutParams(0,dp(124),1);rp2.setMargins(dp(4),dp(4),dp(4),dp(4));row2.addView(scanner,rp2);body.addView(row2);
        LinearLayout row3=new LinearLayout(this);LinearLayout imp=homeCard("✉","Import Email","Ambil data dari lampiran email",Color.rgb(178,133,61));LinearLayout settings=homeCard("⚙","Pengaturan","Atur aplikasi & preferensi",Color.rgb(104,82,58));
        LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(0,dp(124),1);ip.setMargins(dp(4),dp(4),dp(4),dp(4));row3.addView(imp,ip);LinearLayout.LayoutParams ip2=new LinearLayout.LayoutParams(0,dp(124),1);ip2.setMargins(dp(4),dp(4),dp(4),dp(4));row3.addView(settings,ip2);body.addView(row3);

        LinearLayout safe=new LinearLayout(this);safe.setGravity(Gravity.CENTER_VERTICAL);safe.setPadding(dp(16),dp(10),dp(16),dp(10));safe.setBackground(roundedStroke(parchment,18,Color.rgb(191,157,103)));TextView shield=tv("🛡",27,Color.rgb(11,130,190));shield.setGravity(Gravity.CENTER);shield.setBackground(rounded(wood,14));safe.addView(shield,new LinearLayout.LayoutParams(dp(52),dp(52)));LinearLayout st=new LinearLayout(this);st.setOrientation(LinearLayout.VERTICAL);st.setPadding(dp(12),0,0,0);TextView sh=tv("Siap & Aman",17,text);sh.setTypeface(null,1);TextView sd=tv("Data produk Anda selalu terpantau.",13,muted);st.addView(sh);st.addView(sd);safe.addView(st,new LinearLayout.LayoutParams(0,-2,1));TextView online=tv("● Online",15,Color.rgb(0,174,124));online.setTypeface(null,1);safe.addView(online);LinearLayout.LayoutParams slp=new LinearLayout.LayoutParams(-1,dp(76));slp.setMargins(dp(4),dp(14),dp(4),dp(4));body.addView(safe,slp);
        sv.addView(body);r.addView(sv,new LinearLayout.LayoutParams(-1,0,1));

        // Bottom navigation with five clear, full-width targets.
        LinearLayout nav=new LinearLayout(this);nav.setGravity(Gravity.CENTER);nav.setPadding(dp(2),dp(3),dp(2),dp(3));nav.setBackground(rounded(wood,0));
        TextView n1=navItem("⌂","Beranda"),n2=navItem("▣","Produk"),n3=navItem("⏰","Alarm"),n4=navItem("☷","Laporan"),n5=navItem("⚙","Pengaturan");
        TextView[] ns={n1,n2,n3,n4,n5};for(TextView n:ns){n.setTextSize(12);n.setTextColor(Color.rgb(245,224,181));n.setPadding(dp(2),dp(6),dp(2),dp(5));nav.addView(n,new LinearLayout.LayoutParams(0,dp(70),1));}
        r.addView(nav,new LinearLayout.LayoutParams(-1,dp(74)));
        n1.setTextColor(aqua);n2.setOnClickListener(v->showProducts());n3.setOnClickListener(v->showAlarms());n4.setOnClickListener(v->showReports());n5.setOnClickListener(v->showSettings());
        products.setOnClickListener(v->showProducts());alarms.setOnClickListener(v->showAlarms());reports.setOnClickListener(v->showReports());scanner.setOnClickListener(v->startActivity(new Intent(this,AddProductActivity.class).putExtra("scanNow",true)));imp.setOnClickListener(v->openImportPicker());settings.setOnClickListener(v->showSettings());
        setContentView(r);
    }
    void updateStats(TextView a,TextView b,TextView c,TextView d){int ex=0,s7=0,s30=0;for(Product p:db.all()){long x=days(p.expiry);if(x<0)ex++;else if(x<=7)s7++;else if(x<=30)s30++;}a.setText("📦  Total Produk\n"+db.all().size());b.setText("🚨  Expired\n"+ex);c.setText("⏳  ≤ 7 Hari\n"+s7);d.setText("📅  ≤ 30 Hari\n"+s30);}
    long days(String e){try{SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd",Locale.US);f.setLenient(false);Date d=f.parse(e);Calendar end=Calendar.getInstance();end.setTime(d);end.set(Calendar.HOUR_OF_DAY,23);end.set(Calendar.MINUTE,59);end.set(Calendar.SECOND,59);Calendar now=Calendar.getInstance();return (end.getTimeInMillis()-now.getTimeInMillis())/86400000L;}catch(Exception x){return 999999;}}
    TextView productRow(Product p){long d=days(p.expiry);String status=d<0?"EXPIRED":d==0?"HARI INI":d+" hari lagi";int col=d<0?red:d<=7?Color.rgb(173,111,22):Color.rgb(57,105,60);TextView row=tv("▣  "+p.name+"\n     "+(p.barcode==null||p.barcode.isEmpty()?"Tanpa barcode":"Barcode: "+p.barcode)+"\n     Exp: "+p.expiry+"    "+status,15,text);row.setPadding(dp(14),dp(13),dp(12),dp(13));GradientDrawable bg=new GradientDrawable();bg.setColor(parchment);bg.setCornerRadius(dp(12));bg.setStroke(dp(1),Color.rgb(191,157,103));row.setBackground(bg);row.setOnClickListener(v->showProductDetail(p));row.setOnLongClickListener(v->{new AlertDialog.Builder(this).setTitle("Hapus produk?").setMessage(p.name).setNegativeButton("Batal",null).setPositiveButton("Hapus",(d1,w)->{db.deleteProduct(p.id);showProducts();}).show();return true;});return row;}
    void showProductDetail(Product p){base("Detail Produk",p.name);long d=days(p.expiry);TextView card=tv("📦  "+p.name+"\n\n▥ Barcode     "+(p.barcode==null||p.barcode.isEmpty()?"-":p.barcode)+"\n\n▣ Exp Date     "+p.expiry+"\n\n"+(d<0?"🚨  "+(-d)+" hari sejak expired":d+" hari menuju expired"),18,text);card.setPadding(dp(18),dp(18),dp(18),dp(18));card.setBackground(roundedStroke(parchment,14,Color.rgb(191,157,103)));content.addView(card);TextView note=tv(d<0?"Produk ini sudah EXPIRED. Segera lakukan pengecekan stok.":d<=7?"Perhatian: masa expired kurang dari 7 hari.":"Produk masih dalam masa aman.",15,d<0?red:text);note.setPadding(dp(8),dp(14),dp(8),dp(14));content.addView(note);Button edit=button("✎  Edit / Perbarui Produk");content.addView(edit,new LinearLayout.LayoutParams(-1,dp(58)));edit.setOnClickListener(v->startActivity(new Intent(this,AddProductActivity.class).putExtra("editId",p.id)));}void showProducts(){base("Daftar Produk","Pantau semua tanggal expired dengan mudah");EditText search=new EditText(this);search.setHint("🔎  Cari nama produk / barcode...");search.setSingleLine();search.setTextSize(16);search.setPadding(dp(14),0,dp(14),0);search.setBackground(roundedStroke(parchment,12,Color.rgb(191,157,103)));content.addView(search,new LinearLayout.LayoutParams(-1,dp(54)));LinearLayout filters=new LinearLayout(this);filters.setPadding(0,dp(10),0,dp(8));String[] fs={"Semua","Expired","≤ 7 Hari","≤ 30 Hari"};Button[] fb=new Button[4];for(int i=0;i<4;i++){fb[i]=button(fs[i]);fb[i].setTextSize(12);fb[i].setTextColor(text);fb[i].setBackground(roundedStroke(i==0?Color.rgb(229,211,171):parchment,10,Color.rgb(191,157,103)));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(52),1);lp.setMargins(dp(3),0,dp(3),0);filters.addView(fb[i],lp);}content.addView(filters);Button add=button("＋  Tambah Produk"),scan=button("▥  Scan Barcode");LinearLayout actions=new LinearLayout(this);LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,dp(58),1);ap.setMargins(0,0,dp(5),dp(10));actions.addView(add,ap);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(58),1);sp.setMargins(dp(5),0,0,dp(10));actions.addView(scan,sp);content.addView(actions);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);content.addView(list);final int[] mode={0};Runnable refresh=()->{list.removeAllViews();String q=search.getText().toString().trim();for(Product p:(q.isEmpty()?db.all():db.search(q))){long d=days(p.expiry);boolean ok=mode[0]==0||(mode[0]==1&&d<0)||(mode[0]==2&&d>=0&&d<=7)||(mode[0]==3&&d>=0&&d<=30);if(ok){list.addView(productRow(p),new LinearLayout.LayoutParams(-1,LinearLayout.LayoutParams.WRAP_CONTENT));Space spc=new Space(this);list.addView(spc,new LinearLayout.LayoutParams(1,dp(8)));}}};refresh.run();search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){}public void onTextChanged(CharSequence s,int a,int b,int c){refresh.run();}public void afterTextChanged(android.text.Editable e){}});for(int i=0;i<4;i++){final int x=i;fb[i].setOnClickListener(v->{mode[0]=x;for(int j=0;j<4;j++)fb[j].setBackground(roundedStroke(j==x?Color.rgb(229,211,171):parchment,10,Color.rgb(191,157,103)));refresh.run();});}scan.setOnClickListener(v->startActivity(new Intent(this,AddProductActivity.class).putExtra("scanNow",true)));add.setOnClickListener(v->startActivity(new Intent(this,AddProductActivity.class)));}void showAlarms(){
        base("Alarm","Alarm produk dan pengingat pekerjaan");
        Button add=button("＋ Buat Alarm Baru");
        content.addView(add);
        TextView hint=tv("Ketuk alarm untuk aktif/nonaktif. Tekan lama untuk menghapus.",12,muted);
        hint.setPadding(4,8,4,12);
        content.addView(hint);
        LinearLayout list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        content.addView(list);
        Runnable refresh=new Runnable(){
            @Override public void run(){
                list.removeAllViews();
                for(AlarmModel a:db.alarms()){
                    TextView r=tv((a.enabled?"● ":"○ ")+new SimpleDateFormat("dd MMM yyyy • HH:mm",new Locale("id","ID")).format(new Date(a.triggerAt))+"\n"+a.title,15,text);
                    r.setPadding(16,14,16,14);
                    GradientDrawable g=new GradientDrawable();
                    g.setColor(Color.WHITE);
                    g.setCornerRadius(18);
                    g.setStroke(1,Color.rgb(224,231,238));
                    r.setBackground(g);
                    r.setOnClickListener(v->{
                        if(a.enabled){
                            AlarmScheduler.cancel(MainActivity.this,a.id);
                            db.setAlarmEnabled(a.id,false);
                        }else{
                            db.setAlarmEnabled(a.id,true);
                            AlarmScheduler.schedule(MainActivity.this,a.id,a.triggerAt,a.title);
                        }
                        run();
                    });
                    r.setOnLongClickListener(v->{
                        new AlertDialog.Builder(MainActivity.this)
                            .setTitle("Hapus alarm?")
                            .setMessage(a.title)
                            .setNegativeButton("Batal",null)
                            .setPositiveButton("Hapus",(d,w)->{
                                AlarmScheduler.cancel(MainActivity.this,a.id);
                                db.deleteAlarm(a.id);
                                run();
                            }).show();
                        return true;
                    });
                    list.addView(r,new LinearLayout.LayoutParams(-1,LinearLayout.LayoutParams.WRAP_CONTENT));
                    Space sp=new Space(MainActivity.this);
                    list.addView(sp,new LinearLayout.LayoutParams(1,8));
                }
            }
        };
        refresh.run();
        add.setOnClickListener(v->startActivity(new Intent(this,AddAlarmActivity.class)));
    }
    void showReports(){base("Laporan","Ekspor, backup, dan import data Monitoring EXP");TextView hero=tv("📧  Laporan membantu Anda mengambil tindakan lebih cepat.",17,text);hero.setPadding(8,8,8,20);content.addView(hero);Button email=button("📧 Kirim Produk Expired via Email"),csv=button("↓ Export Semua Produk ke CSV"),backup=button("☁ Backup Data JSON"),imp=button("📥 Import CSV / JSON dari Email");content.addView(email);content.addView(csv);content.addView(backup);content.addView(imp);TextView hint=tv("Import dapat dilakukan langsung dari lampiran email dengan memilih Open with / Buka dengan → Monitoring EXP. Anda juga bisa memilih file dari perangkat.",13,muted);hint.setPadding(8,10,8,18);content.addView(hint);TextView work=tv("\nWORK ASSISTANT\nGunakan alarm untuk deadline kerja, pengecekan stok, rapat, atau tugas berulang.",15,muted);content.addView(work);email.setOnClickListener(v->emailExpired());csv.setOnClickListener(v->exportCsv());backup.setOnClickListener(v->backupJson());imp.setOnClickListener(v->openImportPicker());}
    void showSettings(){base("Pengaturan","Preferensi Monitoring EXP");TextView logo=tv("MONITORING EXP\nAurora Edition",25,text);logo.setTypeface(null,1);logo.setPadding(8,12,8,18);content.addView(logo);Button alarm=button("🔔 Pengaturan Notifikasi & Alarm"),exact=button("⏱ Izinkan Alarm Tepat Waktu"),about=button("ℹ Tentang Aplikasi");content.addView(alarm);content.addView(exact);content.addView(about);alarm.setOnClickListener(v->{if(Build.VERSION.SDK_INT>=33)requestNotifications();Toast.makeText(this,"Notifikasi dicek. Pastikan suara & getar aktif di pengaturan Android.",Toast.LENGTH_LONG).show();});exact.setOnClickListener(v->{if(!AlarmScheduler.exactAllowed(this)){AlarmScheduler.openExactAlarmSettings(this);}else Toast.makeText(this,"Alarm tepat waktu sudah diizinkan.",Toast.LENGTH_SHORT).show();});about.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Monitoring EXP").setMessage("Versi 3.0 Aurora\n\nPantau • Kelola • Ingat • Selalu\n\nAplikasi monitoring expired dengan barcode, alarm, notifikasi, laporan, dan backup.").setPositiveButton("OK",null).show());}
    static final int REQ_IMPORT=901;
    void openImportPicker(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"text/csv","text/comma-separated-values","application/json","text/plain","application/octet-stream"});startActivityForResult(i,REQ_IMPORT);
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==REQ_IMPORT&&resultCode==RESULT_OK&&data!=null)importUri(data.getData());}
    void handleIncoming(Intent i){if(i==null)return;String a=i.getAction();Uri u=i.getData();if(Intent.ACTION_SEND.equals(a)){Object x=i.getParcelableExtra(Intent.EXTRA_STREAM);if(x instanceof Uri)u=(Uri)x;}final Uri incoming=u;if(incoming!=null&&(Intent.ACTION_VIEW.equals(a)||Intent.ACTION_SEND.equals(a))){new Handler().postDelayed(()->importUri(incoming),450);}}
    void importUri(Uri uri){
        if(uri==null)return;try{
            String name=getName(uri);InputStream in=getContentResolver().openInputStream(uri);if(in==null)throw new IOException("File tidak dapat dibuka");StringBuilder sb=new StringBuilder();BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8));String line;while((line=r.readLine())!=null)sb.append(line).append('\n');r.close();String raw=sb.toString().trim();
            int added=0,updated=0; if(raw.startsWith("[")){JSONArray arr=new JSONArray(raw);for(int i=0;i<arr.length();i++){JSONObject o=arr.getJSONObject(i);String b=o.optString("barcode","").trim(),n=o.optString("name",o.optString("nama","")).trim(),e=o.optString("expiry",o.optString("expired","")).trim();if(validRow(b,n,e)){boolean existed=findBarcode(b);long id=db.upsert(b,n,e);scheduleImported(id,n,e);if(existed)updated++;else added++;}}}else{String[] lines=raw.split("\\r?\\n");for(int i=0;i<lines.length;i++){if(lines[i].trim().isEmpty())continue;List<String> a=Csv.parseLine(lines[i]);if(i==0&&isHeader(a))continue;if(a.size()<3)continue;String b=a.get(0).trim(),n=a.get(1).trim(),e=a.get(2).trim();if(validRow(b,n,e)){boolean existed=findBarcode(b);long id=db.upsert(b,n,e);scheduleImported(id,n,e);if(existed)updated++;else added++;}}}
            showHome();new AlertDialog.Builder(this).setTitle("Import selesai ✓").setMessage("File: "+name+"\n\nProduk baru: "+added+"\nProduk diperbarui: "+updated+"\n\nAlarm expired otomatis dijadwalkan ulang.").setPositiveButton("Lihat Produk",(d,w)->showProducts()).setNegativeButton("Tutup",null).show();
        }catch(Exception e){new AlertDialog.Builder(this).setTitle("Import gagal").setMessage("File belum didukung atau formatnya tidak valid.\n\n"+e.getMessage()).setPositiveButton("OK",null).show();}
    }
    boolean isHeader(List<String> a){if(a.isEmpty())return false;String x=a.get(0).toLowerCase(Locale.US);return x.contains("barcode")||x.contains("kode");}
    boolean validRow(String b,String n,String e){if(n.isEmpty()||e.isEmpty())return false;try{SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd",Locale.US);f.setLenient(false);f.parse(e);return true;}catch(Exception x){return false;}}
    boolean findBarcode(String b){if(b==null||b.isEmpty())return false;for(Product p:db.all())if(b.equals(p.barcode))return true;return false;}
    void scheduleImported(long id,String n,String e){try{Date ed=new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(e);db.clearProductAlarms(id);Calendar c=Calendar.getInstance();c.setTime(ed);c.set(Calendar.HOUR_OF_DAY,8);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);int[] offsets={30,7,1,0};for(int off:offsets){Calendar a=(Calendar)c.clone();a.add(Calendar.DAY_OF_YEAR,-off);long at=a.getTimeInMillis();if(at>System.currentTimeMillis()){long aid=db.addAlarm((off==0?"🚨 EXPIRED: ":"⏰ H-"+off+": ")+n,at,id);AlarmScheduler.schedule(this,aid,at,(off==0?"EXPIRED: ":"H-"+off+": ")+n);}}}catch(Exception ignored){}}
    String getName(Uri u){try{android.database.Cursor c=getContentResolver().query(u,null,null,null,null);if(c!=null){int ix=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(c.moveToFirst()&&ix>=0){String n=c.getString(ix);c.close();return n;}c.close();}}catch(Exception ignored){}return String.valueOf(u);}
    void emailExpired(){ArrayList<Product> ex=new ArrayList<>();for(Product p:db.all())if(days(p.expiry)<0)ex.add(p);if(ex.isEmpty()){Toast.makeText(this,"Tidak ada produk expired.",Toast.LENGTH_SHORT).show();return;}try{File f=new File(getCacheDir(),"Produk_Expired.csv");BufferedWriter w=new BufferedWriter(new OutputStreamWriter(new FileOutputStream(f),StandardCharsets.UTF_8));w.write("Barcode,Nama Produk,Tanggal Expired\n");for(Product p:ex)w.write(Csv.esc(p.barcode)+","+Csv.esc(p.name)+","+Csv.esc(p.expiry)+"\n");w.close();share(f,"text/csv","Laporan Produk Expired","Terlampir laporan produk expired.");}catch(Exception e){Toast.makeText(this,e.toString(),Toast.LENGTH_LONG).show();}}
    void exportCsv(){try{File f=new File(getExternalFilesDir(null),"MonitoringEXP.csv");BufferedWriter w=new BufferedWriter(new OutputStreamWriter(new FileOutputStream(f),StandardCharsets.UTF_8));w.write("Barcode,Nama Produk,Tanggal Expired\n");for(Product p:db.all())w.write(Csv.esc(p.barcode)+","+Csv.esc(p.name)+","+Csv.esc(p.expiry)+"\n");w.close();share(f,"text/csv","Monitoring EXP CSV","");}catch(Exception e){Toast.makeText(this,e.toString(),Toast.LENGTH_LONG).show();}}
    void backupJson(){try{File f=new File(getExternalFilesDir(null),"MonitoringEXP_Backup.json");BufferedWriter w=new BufferedWriter(new FileWriter(f));w.write("[\n");int i=0;for(Product p:db.all()){if(i++>0)w.write(",\n");w.write("{\"barcode\":\""+json(p.barcode)+"\",\"name\":\""+json(p.name)+"\",\"expiry\":\""+json(p.expiry)+"\"}");}w.write("\n]");w.close();share(f,"application/json","Backup Monitoring EXP","");}catch(Exception e){Toast.makeText(this,e.toString(),Toast.LENGTH_LONG).show();}}
    String json(String s){return s==null?"":s.replace("\\","\\\\").replace("\"","\\\"");}
    void share(File f,String type,String subject,String body){Uri u=FileProvider.getUriForFile(this,getPackageName()+".fileprovider",f);Intent i=new Intent(Intent.ACTION_SEND);i.setType(type);i.putExtra(Intent.EXTRA_SUBJECT,subject);if(!body.isEmpty())i.putExtra(Intent.EXTRA_TEXT,body);i.putExtra(Intent.EXTRA_STREAM,u);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,"Kirim / Bagikan"));}
    @Override public void onBackPressed(){if(!homePage){showHome();}else{super.onBackPressed();}}
    @Override protected void onResume(){super.onResume();if(db!=null){AlarmScheduler.ensureChannel(this);}}
}
