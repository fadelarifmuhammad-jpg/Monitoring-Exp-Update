package com.supermarket.monitoringexp;

import android.content.*;import android.database.Cursor;import android.database.sqlite.*;import java.util.*;

public class Db extends SQLiteOpenHelper {
    public Db(Context c){super(c,"monitoring_exp.db",null,3);}
    public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,barcode TEXT,name TEXT NOT NULL,expiry TEXT NOT NULL)");
        db.execSQL("CREATE TABLE alarms(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,trigger_at INTEGER NOT NULL,enabled INTEGER NOT NULL DEFAULT 1,product_id INTEGER DEFAULT -1)");
    }
    public void onUpgrade(SQLiteDatabase db,int oldV,int newV){
        if(oldV<2) db.execSQL("CREATE TABLE IF NOT EXISTS alarms(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,trigger_at INTEGER NOT NULL,enabled INTEGER NOT NULL DEFAULT 1,product_id INTEGER DEFAULT -1)");
    }
    public long add(String b,String n,String e){ContentValues v=new ContentValues();v.put("barcode",b);v.put("name",n);v.put("expiry",e);return getWritableDatabase().insert("products",null,v);}
    public long upsert(String b,String n,String e){
        SQLiteDatabase d=getWritableDatabase();
        if(b!=null&&!b.trim().isEmpty()){
            Cursor c=d.rawQuery("SELECT id FROM products WHERE barcode=? LIMIT 1",new String[]{b.trim()});
            if(c.moveToFirst()){long id=c.getLong(0);c.close();ContentValues v=new ContentValues();v.put("name",n);v.put("expiry",e);d.update("products",v,"id=?",new String[]{String.valueOf(id)});return id;}c.close();
        }
        return add(b,n,e);
    }
    public void clearProductAlarms(long productId){getWritableDatabase().delete("alarms","product_id=?",new String[]{String.valueOf(productId)});}
    public void deleteProduct(long id){getWritableDatabase().delete("products","id=?",new String[]{String.valueOf(id)});getWritableDatabase().delete("alarms","product_id=?",new String[]{String.valueOf(id)});}
    public List<Product> all(){return query("SELECT id,barcode,name,expiry FROM products ORDER BY expiry ASC,name ASC",null);}
    public List<Product> search(String q){String l="%"+q+"%";return query("SELECT id,barcode,name,expiry FROM products WHERE barcode LIKE ? OR name LIKE ? ORDER BY expiry ASC,name ASC",new String[]{l,l});}
    private List<Product> query(String sql,String[] args){ArrayList<Product> o=new ArrayList<>();Cursor c=getReadableDatabase().rawQuery(sql,args);while(c.moveToNext())o.add(new Product(c.getLong(0),c.getString(1),c.getString(2),c.getString(3)));c.close();return o;}
    public long addAlarm(String title,long at,long productId){ContentValues v=new ContentValues();v.put("title",title);v.put("trigger_at",at);v.put("enabled",1);v.put("product_id",productId);return getWritableDatabase().insert("alarms",null,v);}
    public List<AlarmModel> alarms(){ArrayList<AlarmModel>o=new ArrayList<>();Cursor c=getReadableDatabase().rawQuery("SELECT id,title,trigger_at,enabled,product_id FROM alarms ORDER BY trigger_at ASC",null);while(c.moveToNext())o.add(new AlarmModel(c.getLong(0),c.getString(1),c.getLong(2),c.getInt(3)==1,c.getLong(4)));c.close();return o;}
    public void setAlarmEnabled(long id,boolean enabled){ContentValues v=new ContentValues();v.put("enabled",enabled?1:0);getWritableDatabase().update("alarms",v,"id=?",new String[]{String.valueOf(id)});}
    public void deleteAlarm(long id){getWritableDatabase().delete("alarms","id=?",new String[]{String.valueOf(id)});}
}
