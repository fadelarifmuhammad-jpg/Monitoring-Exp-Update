package com.supermarket.monitoringexp;
import android.content.*;
public class BootReceiver extends BroadcastReceiver { public void onReceive(Context c,Intent i){AlarmScheduler.ensureChannel(c);AlarmScheduler.scheduleEnabled(c);} }
