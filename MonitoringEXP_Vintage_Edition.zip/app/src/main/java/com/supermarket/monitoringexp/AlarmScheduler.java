package com.supermarket.monitoringexp;

import android.app.*;import android.content.*;import android.os.Build;import android.provider.Settings;

public class AlarmScheduler {
    public static final String CHANNEL="monitoring_exp_alarm";
    public static void ensureChannel(Context c){
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel ch=new NotificationChannel(CHANNEL,"Monitoring EXP • Alarm",NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("Alarm expired dan pengingat pekerjaan");ch.enableVibration(true);ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }
    public static boolean exactAllowed(Context c){return Build.VERSION.SDK_INT<31 || ((AlarmManager)c.getSystemService(Context.ALARM_SERVICE)).canScheduleExactAlarms();}
    public static void openExactAlarmSettings(Context c){if(Build.VERSION.SDK_INT>=31){try{c.startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,android.net.Uri.parse("package:"+c.getPackageName())));}catch(Exception ignored){}}}
    public static void schedule(Context c,long id,long at,String title){
        if(at<=System.currentTimeMillis()) return;
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        Intent i=new Intent(c,AlarmReceiver.class).putExtra("alarmId",id).putExtra("title",title);
        PendingIntent pi=PendingIntent.getBroadcast(c,(int)id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        if(Build.VERSION.SDK_INT>=31 && am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);
        else if(Build.VERSION.SDK_INT>=23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi); else am.set(AlarmManager.RTC_WAKEUP,at,pi);
    }
    public static void cancel(Context c,long id){
        Intent i=new Intent(c,AlarmReceiver.class);PendingIntent pi=PendingIntent.getBroadcast(c,(int)id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);((AlarmManager)c.getSystemService(Context.ALARM_SERVICE)).cancel(pi);
    }
    public static void scheduleEnabled(Context c){Db db=new Db(c);for(AlarmModel a:db.alarms())if(a.enabled&&a.triggerAt>System.currentTimeMillis())schedule(c,a.id,a.triggerAt,a.title);}
}
