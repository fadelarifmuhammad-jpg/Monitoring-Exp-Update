package com.supermarket.monitoringexp;
import java.util.*;
public class Csv {
    public static String esc(String s){ if(s==null)s=""; return "\""+s.replace("\"","\"\"")+"\""; }
    public static List<String> parseLine(String line){ ArrayList<String>a=new ArrayList<>();StringBuilder b=new StringBuilder();boolean q=false;for(int i=0;i<line.length();i++){char ch=line.charAt(i);if(ch=='\"'){if(q&&i+1<line.length()&&line.charAt(i+1)=='\"'){b.append('\"');i++;}else q=!q;}else if(ch==','&&!q){a.add(b.toString());b.setLength(0);}else b.append(ch);}a.add(b.toString());return a;}
}
