package com.supermarket.monitoringexp;
public class AlarmModel { public long id,triggerAt,productId; public String title; public boolean enabled; public AlarmModel(long i,String t,long a,boolean e,long p){id=i;title=t;triggerAt=a;enabled=e;productId=p;} }
