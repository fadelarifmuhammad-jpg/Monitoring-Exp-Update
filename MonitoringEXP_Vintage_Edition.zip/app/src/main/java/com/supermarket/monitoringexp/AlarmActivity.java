package com.supermarket.monitoringexp;

import android.app.*;import android.graphics.*;import android.graphics.drawable.*;import android.os.*;import android.view.*;import android.widget.*;import androidx.core.app.NotificationManagerCompat;

public class AlarmActivity extends Activity {
    public void onCreate(Bundle b){super.onCreate(b);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON|WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED|WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);build();}
    GradientDrawable bg(){return new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(7,26,51),Color.rgb(20,119,184),Color.rgb(75,46,131)});}
    TextView tv(String s,float z){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(z);t.setGravity(Gravity.CENTER);return t;}
    public void build(){
        LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setGravity(Gravity.CENTER);r.setPadding(30,30,30,30);r.setBackground(bg());
        TextView icon=tv("⏰",76);r.addView(icon,new LinearLayout.LayoutParams(-1,120));
        TextView over=tv("MONITORING EXP",14);over.setLetterSpacing(.12f);r.addView(over);
        TextView title=tv(getIntent().getStringExtra("title"),28);title.setTypeface(null,1);title.setPadding(10,18,10,32);r.addView(title);
        TextView now=tv("Waktunya perhatian.",17);now.setTextColor(Color.rgb(210,245,255));r.addView(now);
        Space sp=new Space(this);r.addView(sp,new LinearLayout.LayoutParams(1,24));
        Button snooze=new Button(this);snooze.setText("SNOOZE 10 MENIT");snooze.setAllCaps(false);r.addView(snooze,new LinearLayout.LayoutParams(-1,60));
        Button stop=new Button(this);stop.setText("MATIKAN ALARM");stop.setAllCaps(false);r.addView(stop,new LinearLayout.LayoutParams(-1,60));
        setContentView(r);
        stop.setOnClickListener(v->{stopAlarm();finish();});
        snooze.setOnClickListener(v->{stopAlarm();long id=System.currentTimeMillis()%1000000;AlarmScheduler.schedule(this,id,System.currentTimeMillis()+600000,"Snooze: "+getIntent().getStringExtra("title"));finish();});
    }
    void stopAlarm(){AlarmReceiver.UriAlarmHolder.stop();int id=getIntent().getIntExtra("alarmId",0);if(id!=0)((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).cancel(id);}
    protected void onDestroy(){super.onDestroy();}
}
