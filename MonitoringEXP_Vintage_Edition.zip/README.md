# Monitoring EXP — Vintage Edition

Dashboard monitoring produk expired dengan tema vintage/parchment.

Fitur utama:
- Dashboard vintage dengan tombol besar
- Daftar produk dengan pencarian
- Filter Semua / Expired / ≤ 7 Hari / ≤ 30 Hari
- Detail produk dan status expired yang jelas
- Tombol kembali yang mudah ditemukan
- Scan barcode
- Alarm H-30, H-7, H-1 dan Hari H
- Import CSV/JSON termasuk lampiran email
- Export CSV dan backup JSON

Build: Android SDK 35, JDK 17, Gradle 8.9.
